package com.linkflow.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.URLUtil;
import android.widget.*;
import android.text.TextUtils;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private EditText input;
    private TextView status, address;
    private WebView web;
    private LinearLayout page;
    private int bg = Color.rgb(15, 18, 32);
    private int panel = Color.rgb(29, 34, 54);
    private int accent = Color.rgb(112, 132, 255);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(18, 20, 18, 12);

        TextView brand = label("LINKFLOW  •  UNIVERSAL LINK OPENER", 12, 0xffAAB6FF, true);
        root.addView(brand);

        TextView title = label("Open any link.", 29, Color.WHITE, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = 12; root.addView(title, tp);

        TextView sub = label("Resolve public redirects. Continue website verification in the built-in browser.", 14, 0xffB8BED2, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 5; root.addView(sub, sp);

        input = new EditText(this);
        input.setSingleLine(false); input.setMinLines(2); input.setTextSize(14);
        input.setHint("Paste a shortlink here…"); input.setHintTextColor(0xff858DA8);
        input.setTextColor(Color.WHITE); input.setPadding(14, 12, 14, 12);
        input.setBackground(shape(panel, 24));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = 18; root.addView(input, ip);

        Button open = new Button(this);
        open.setText("RESOLVE & OPEN  ↗");
        open.setTextColor(Color.WHITE); open.setAllCaps(false);
        open.setBackground(shape(accent, 24));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 10; root.addView(open, bp);
        open.setOnClickListener(v -> loadLink());

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        status = label("Ready for a link", 12, 0xffAAB6FF, false);
        row.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        Button copy = new Button(this);
        copy.setText("Copy URL"); copy.setAllCaps(false);
        copy.setTextColor(Color.WHITE); copy.setBackground(shape(panel, 18));
        row.addView(copy);
        copy.setOnClickListener(v -> {
            String url = web == null ? "" : web.getUrl();
            if (TextUtils.isEmpty(url)) url = input.getText().toString().trim();
            if (!TextUtils.isEmpty(url)) {
                ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("URL", url));
                Toast.makeText(this, "URL copied", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = 8; root.addView(row, rp);

        address = label("Destination will appear here", 11, 0xff8D96B2, false);
        address.setMaxLines(2); address.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = 4; root.addView(address, ap);

        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                status.setText("Opening page…");
                address.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                status.setText("Page loaded • verification may be required");
                address.setText(url);
            }
        });
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 0, 1);
        wp.topMargin = 12; root.addView(web, wp);

        setContentView(root);
    }

    private void loadLink() {
        String url = input.getText().toString().trim();
        if (url.isEmpty()) {
            input.setError("Paste a link first");
            return;
        }
        if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
        if (!URLUtil.isValidUrl(url)) {
            input.setError("Please enter a valid URL");
            return;
        }
        try {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        } catch (Exception ignored) {}
        status.setText("Following public redirects…");
        web.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
