package com.linkflow.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipboardManager;
import android.content.ClipData;

public class MainActivity extends Activity {
    private EditText urlInput;
    private TextView status, currentUrl;
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,19,34));
        getWindow().setNavigationBarColor(Color.rgb(16,19,34));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(12));
        root.setBackgroundColor(Color.rgb(16,19,34));

        TextView brand = new TextView(this);
        brand.setText("LINKFLOW");
        brand.setTextColor(Color.rgb(157,174,255));
        brand.setTextSize(13);
        brand.setTypeface(null, Typeface.BOLD);
        brand.setLetterSpacing(.12f);
        root.addView(brand);

        TextView title = new TextView(this);
        title.setText("Open any link");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, dp(8), 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Follow public redirects and continue in the built-in browser.");
        subtitle.setTextColor(Color.rgb(170,177,198));
        subtitle.setTextSize(14);
        root.addView(subtitle);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setHint("Paste a shortlink here");
        urlInput.setHintTextColor(Color.rgb(150,158,181));
        urlInput.setTextColor(Color.WHITE);
        urlInput.setTextSize(15);
        urlInput.setPadding(dp(14), dp(10), dp(14), dp(10));
        urlInput.setBackgroundColor(Color.rgb(39,45,65));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(54));
        inputParams.topMargin = dp(18);
        root.addView(urlInput, inputParams);

        Button open = new Button(this);
        open.setText("Resolve & Open");
        open.setTextColor(Color.WHITE);
        open.setAllCaps(false);
        open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(99,119,255)));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(52));
        buttonParams.topMargin = dp(10);
        root.addView(open, buttonParams);

        status = new TextView(this);
        status.setText("Ready");
        status.setTextColor(Color.rgb(170,177,198));
        status.setTextSize(12);
        status.setPadding(0, dp(10), 0, dp(4));
        root.addView(status);

        currentUrl = new TextView(this);
        currentUrl.setText("Destination URL will appear here after navigation.");
        currentUrl.setTextColor(Color.rgb(180,190,220));
        currentUrl.setTextSize(12);
        currentUrl.setPadding(dp(10), dp(8), dp(10), dp(8));
        currentUrl.setBackgroundColor(Color.rgb(30,35,52));
        root.addView(currentUrl, new LinearLayout.LayoutParams(-1, -2));

        Button copy = new Button(this);
        copy.setText("Copy current URL");
        copy.setAllCaps(false);
        copy.setTextColor(Color.WHITE);
        copy.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(49,57,80)));
        root.addView(copy);

        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                status.setText("Loading destination…");
                currentUrl.setText(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                status.setText("Page loaded. Complete any required verification on the page.");
                currentUrl.setText(url);
            }
        });
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        webParams.topMargin = dp(10);
        root.addView(webView, webParams);

        open.setOnClickListener(v -> {
            String value = urlInput.getText().toString().trim();
            if (value.isEmpty()) {
                Toast.makeText(this, "Paste a link first", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!value.matches("(?i)^https?://.*")) value = "https://" + value;
            try {
                java.net.URI parsed = java.net.URI.create(value);
                if (parsed.getHost() == null) throw new IllegalArgumentException();
                ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
                webView.loadUrl(value);
            } catch (Exception e) {
                Toast.makeText(this, "Please enter a valid http/https URL", Toast.LENGTH_LONG).show();
            }
        });

        copy.setOnClickListener(v -> {
            String value = webView.getUrl();
            if (value == null || value.isEmpty()) value = currentUrl.getText().toString();
            ClipboardManager clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("LinkFlow URL", value));
            Toast.makeText(this, "URL copied", Toast.LENGTH_SHORT).show();
        });

        setContentView(root);
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
